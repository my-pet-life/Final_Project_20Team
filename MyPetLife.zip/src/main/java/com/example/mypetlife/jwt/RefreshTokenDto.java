package com.example.mypetlife.jwt;

import lombok.Data;

@Data
public class RefreshTokenDto {

    private String refreshToken;
}
