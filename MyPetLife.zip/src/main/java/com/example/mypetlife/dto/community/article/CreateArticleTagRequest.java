package com.example.mypetlife.dto.community.article;

import lombok.Data;

@Data
public class CreateArticleTagRequest {

    private String tagName;
}
