package com.example.mypetlife.entity.user;

public enum Authority {

    ROLE_USER,
    ROLE_ADMIN
}
