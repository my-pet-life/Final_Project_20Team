package com.example.mypetlife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MypetlifeApplicationTests {

	@Test
	void contextLoads() {
	}

}
